﻿# Shell Configuration
Set-Alias -Name Clear-AWSCredentials -Value Clear-AWSCredential
Set-Alias -Name Clear-AWSDefaults -Value Clear-AWSDefaultConfiguration
Set-Alias -Name Get-AWSCredentials -Value Get-AWSCredential
Set-Alias -Name Initialize-AWSDefaults -Value Initialize-AWSDefaultConfiguration
Set-Alias -Name New-AWSCredentials -Value New-AWSCredential
Set-Alias -Name Set-AWSCredentials -Value Set-AWSCredential

# AlexaForBusiness
Set-Alias -Name Add-ALXBContactWithAddressBook -Value Add-ALXBContactToAddressBook
Set-Alias -Name Remove-ALXBSmartHomeAppliances -Value Remove-ALXBSmartHomeAppliance

# ApiGatewayV2
Set-Alias -Name Get-AG2ApiLis -Value Get-AG2ApiList

# ApplicationAutoScaling
Set-Alias -Name Write-AASScalingPolicy -Value Set-AASScalingPolicy

# ApplicationDiscoveryService
Set-Alias -Name Remove-ADSApplications -Value Remove-ADSApplication

# AutoScaling
Set-Alias -Name Add-ASInstances -Value Mount-ASInstance
Set-Alias -Name Dismount-ASInstances -Value Dismount-ASInstance
Set-Alias -Name Get-ASAccountLimits -Value Get-ASAccountLimit
Set-Alias -Name Get-ASLifecycleHooks -Value Get-ASLifecycleHook
Set-Alias -Name Get-ASLifecycleHookTypes -Value Get-ASLifecycleHookType

# AWSSupport
Set-Alias -Name Get-ASACases -Value Get-ASACase
Set-Alias -Name Get-ASACommunications -Value Get-ASACommunication
Set-Alias -Name Get-ASAServices -Value Get-ASAService
Set-Alias -Name Get-ASASeverityLevels -Value Get-ASASeverityLevel
Set-Alias -Name Get-ASATrustedAdvisorCheckRefreshStatuses -Value Get-ASATrustedAdvisorCheckRefreshStatus
Set-Alias -Name Get-ASATrustedAdvisorChecks -Value Get-ASATrustedAdvisorCheck
Set-Alias -Name Get-ASATrustedAdvisorCheckSummaries -Value Get-ASATrustedAdvisorCheckSummary

# Backup
Set-Alias -Name Remove-BAKBackupVaultNotifications -Value Remove-BAKBackupVaultNotification

# Batch
Set-Alias -Name Get-BATJobsList -Value Get-BATJobList

# CloudFormation
Set-Alias -Name Get-CFNAccountLimits -Value Get-CFNAccountLimit
Set-Alias -Name Get-CFNStackEvents -Value Get-CFNStackEvent
Set-Alias -Name Get-CFNStackResources -Value Get-CFNStackResourceList
Set-Alias -Name Get-CFNStackResourceSummaries -Value Get-CFNStackResourceSummary
Set-Alias -Name Get-CFNStackSummaries -Value Get-CFNStackSummary

# CloudFront
Set-Alias -Name Get-CFCloudFrontOriginAccessIdentities -Value Get-CFCloudFrontOriginAccessIdentityList
Set-Alias -Name Get-CFDistributions -Value Get-CFDistributionList
Set-Alias -Name Get-CFInvalidations -Value Get-CFInvalidationList
Set-Alias -Name Get-CFStreamingDistributions -Value Get-CFStreamingDistributionList

# CloudHSM
Set-Alias -Name Get-HSMAvailableZones -Value Get-HSMAvailableZone

# CloudSearch
Set-Alias -Name Get-CSAnalysisSchemes -Value Get-CSAnalysisScheme
Set-Alias -Name Get-CSAvailabilityOptions -Value Get-CSAvailabilityOption
Set-Alias -Name Get-CSIndexFields -Value Get-CSIndexField
Set-Alias -Name Get-CSListDomainNames -Value Get-CSDomainNameList
Set-Alias -Name Get-CSScalingParameters -Value Get-CSScalingParameter
Set-Alias -Name Get-CSServiceAccessPolicies -Value Get-CSServiceAccessPolicy
Set-Alias -Name Update-CSAvailabilityOptions -Value Update-CSAvailabilityOption
Set-Alias -Name Update-CSScalingParameters -Value Update-CSScalingParameter
Set-Alias -Name Update-CSServiceAccessPolicies -Value Update-CSServiceAccessPolicy

# CloudSearchDomain
Set-Alias -Name Get-CSDSuggestions -Value Get-CSDSuggestion
Set-Alias -Name Search-CSDDocuments -Value Search-CSDDocument
Set-Alias -Name Write-CSDDocuments -Value Write-CSDDocument

# CloudTrail
Set-Alias -Name Add-CTTag -Value Add-CTResourceTag
Set-Alias -Name Find-CTEvents -Value Find-CTEvent
Set-Alias -Name Get-CTEventSelectors -Value Get-CTEventSelector
Set-Alias -Name Get-CTTag -Value Get-CTResourceTag
Set-Alias -Name Remove-CTTag -Value Remove-CTResourceTag
Set-Alias -Name Write-CTEventSelectors -Value Write-CTEventSelector

# CloudWatch
Set-Alias -Name Get-CWMetrics -Value Get-CWMetricList
Set-Alias -Name Get-CWMetricStatistics -Value Get-CWMetricStatistic

# CloudWatchLogs
Set-Alias -Name Get-CWLExportTasks -Value Get-CWLExportTask
Set-Alias -Name Get-CWLLogEvents -Value Get-CWLLogEvent
Set-Alias -Name Get-CWLLogGroups -Value Get-CWLLogGroup
Set-Alias -Name Get-CWLLogStreams -Value Get-CWLLogStream
Set-Alias -Name Get-CWLMetricFilters -Value Get-CWLMetricFilter
Set-Alias -Name Get-CWLSubscriptionFilters -Value Get-CWLSubscriptionFilter
Set-Alias -Name Write-CWLLogEvents -Value Write-CWLLogEvent

# CodeDeploy
Set-Alias -Name Get-CDApplications -Value Get-CDApplicationBatch
Set-Alias -Name Get-CDDeployments -Value Get-CDDeploymentBatch

# CodePipeline
Set-Alias -Name Get-CPActionableJobs -Value Get-CPActionableJobList
Set-Alias -Name Get-CPActionableThirdPartyJobs -Value Get-CPActionableThirdPartyJobList
Set-Alias -Name Get-CPJobDetails -Value Get-CPJobDetail
Set-Alias -Name Get-CPThirdPartyJobDetails -Value Get-CPThirdPartyJobDetail

# ConfigService
Set-Alias -Name Get-CFGConfigRules -Value Get-CFGConfigRule
Set-Alias -Name Get-CFGConfigurationRecorders -Value Get-CFGConfigurationRecorder
Set-Alias -Name Get-CFGDeliveryChannels -Value Get-CFGDeliveryChannel
Set-Alias -Name Write-CFGEvaluations -Value Write-CFGEvaluation

# CostAndUsageReport
Set-Alias -Name Get-CURReportDefinitions -Value Get-CURReportDefinition

# DataPipeline
Set-Alias -Name Add-DPTags -Value Add-DPResourceTag
Set-Alias -Name Remove-DPTags -Value Remove-DPResourceTag

# DirectConnect
Set-Alias -Name Get-DCLocations -Value Get-DCLocation

# DirectoryService
Set-Alias -Name Add-DSIpRoutes -Value Add-DSIpRoute
Set-Alias -Name Get-DSIpRoutes -Value Get-DSIpRouteList
Set-Alias -Name Remove-DSIpRoutes -Value Remove-DSIpRoute

# DynamoDBv2
Set-Alias -Name Get-DDBBackupsList -Value Get-DDBBackupList
Set-Alias -Name Get-DDBTables -Value Get-DDBTableList
Set-Alias -Name Get-GlobalTablesList -Value Get-GlobalTableList

# EC2
Set-Alias -Name Confirm-EC2EndpointConnection -Value Approve-EC2EndpointConnection
Set-Alias -Name Confirm-EC2ReservedInstancesExchangeQuote -Value Approve-EC2ReservedInstancesExchangeQuote
Set-Alias -Name Confirm-EC2TransitGatewayPeeringAttachment -Value Approve-EC2TransitGatewayPeeringAttachment
Set-Alias -Name Confirm-EC2TransitGatewayVpcAttachment -Value Approve-EC2TransitGatewayVpcAttachment
Set-Alias -Name Confirm-EC2VpcPeeringConnection -Value Approve-EC2VpcPeeringConnection
Set-Alias -Name Edit-EC2Hosts -Value Edit-EC2Host
Set-Alias -Name Get-EC2AccountAttributes -Value Get-EC2AccountAttribute
Set-Alias -Name Get-EC2ExportTasks -Value Get-EC2ExportTask
Set-Alias -Name Get-EC2FlowLogs -Value Get-EC2FlowLog
Set-Alias -Name Get-EC2Hosts -Value Get-EC2Host
Set-Alias -Name Get-EC2ReservedInstancesModifications -Value Get-EC2ReservedInstancesModification
Set-Alias -Name Get-EC2Snapshots -Value Get-EC2Snapshot
Set-Alias -Name Get-EC2VpcPeeringConnections -Value Get-EC2VpcPeeringConnection
Set-Alias -Name New-EC2FlowLogs -Value New-EC2FlowLog
Set-Alias -Name New-EC2Hosts -Value New-EC2Host
Set-Alias -Name ReleaseHosts -Value Remove-EC2Host
Set-Alias -Name Remove-EC2FlowLogs -Value Remove-EC2FlowLog

# ECS
Set-Alias -Name Get-ECSClusters -Value Get-ECSClusterList
Set-Alias -Name Get-ECSContainerInstances -Value Get-ECSContainerInstanceList
Set-Alias -Name Get-ECSTaskDefinitionFamilies -Value Get-ECSTaskDefinitionFamilyList
Set-Alias -Name Get-ECSTaskDefinitions -Value Get-ECSTaskDefinitionList
Set-Alias -Name Get-ECSTasks -Value Get-ECSTaskList

# ElastiCache
Set-Alias -Name Get-ECCacheEngineVersions -Value Get-ECCacheEngineVersion
Set-Alias -Name Get-ECCacheSubnetGroups -Value Get-ECCacheSubnetGroup
Set-Alias -Name Get-ECReplicationGroups -Value Get-ECReplicationGroup
Set-Alias -Name Get-ECSnapshots -Value Get-ECSnapshot

# ElasticBeanstalk
Set-Alias -Name Get-EBApplications -Value Get-EBApplication
Set-Alias -Name Get-EBApplicationVersions -Value Get-EBApplicationVersion
Set-Alias -Name Get-EBAvailableSolutionStack -Value Get-EBAvailableSolutionStackList
Set-Alias -Name Get-EBConfigurationOptions -Value Get-EBConfigurationOption
Set-Alias -Name Get-EBConfigurationSettings -Value Get-EBConfigurationSetting
Set-Alias -Name Get-EBEnvironmentResources -Value Get-EBEnvironmentResource
Set-Alias -Name Set-EBEnvironmentCNAMEs -Value Set-EBEnvironmentCNAME
Set-Alias -Name Test-EBConfigurationSettings -Value Test-EBConfigurationSetting

# ElasticLoadBalancing
Set-Alias -Name Add-ELBTags -Value Add-ELBResourceTag
Set-Alias -Name Get-ELBTags -Value Get-ELBResourceTag
Set-Alias -Name Remove-ELBTags -Value Remove-ELBResourceTag

# ElasticMapReduce
Set-Alias -Name Add-EMRTag -Value Add-EMRResourceTag
Set-Alias -Name Get-EMRBootstrapActions -Value Get-EMRBootstrapActionList
Set-Alias -Name Get-EMRClusters -Value Get-EMRClusterList
Set-Alias -Name Get-EMRInstanceFleets -Value Get-EMRInstanceFleetList
Set-Alias -Name Get-EMRInstanceGroups -Value Get-EMRInstanceGroupList
Set-Alias -Name Get-EMRInstances -Value Get-EMRInstanceList
Set-Alias -Name Get-EMRSteps -Value Get-EMRStepList
Set-Alias -Name Remove-EMRTag -Value Remove-EMRResourceTag
Set-Alias -Name Set-EMRVisibleToAllUsers -Value Set-EMRVisibleToAllUser
Set-Alias -Name Stop-EMRSteps -Value Stop-EMRStep

# Elasticsearch
Set-Alias -Name Add-ESTag -Value Add-ESResourceTag
Set-Alias -Name Get-ESTag -Value Get-ESResourceTag
Set-Alias -Name Remove-ESTag -Value Remove-ESResourceTag

# ElasticTranscoder
Set-Alias -Name Update-ETSPipelineNotifications -Value Update-ETSPipelineNotification

# Glacier
Set-Alias -Name Get-GLCVaultTagsList -Value Get-GLCVaultTagList

# Glue
Set-Alias -Name Get-GLUECrawlerMetricsList -Value Get-GLUECrawlerMetricList

# IdentityManagement
Set-Alias -Name Get-IAMAccountAuthorizationDetails -Value Get-IAMAccountAuthorizationDetail
Set-Alias -Name Get-IAMAttachedGroupPolicies -Value Get-IAMAttachedGroupPolicyList
Set-Alias -Name Get-IAMAttachedRolePolicies -Value Get-IAMAttachedRolePolicyList
Set-Alias -Name Get-IAMAttachedUserPolicies -Value Get-IAMAttachedUserPolicyList
Set-Alias -Name Get-IAMGroupPolicies -Value Get-IAMGroupPolicyList
Set-Alias -Name Get-IAMGroups -Value Get-IAMGroupList
Set-Alias -Name Get-IAMInstanceProfiles -Value Get-IAMInstanceProfileList
Set-Alias -Name Get-IAMOpenIDConnectProviders -Value Get-IAMOpenIDConnectProviderList
Set-Alias -Name Get-IAMPolicies -Value Get-IAMPolicyList
Set-Alias -Name Get-IAMPolicyVersions -Value Get-IAMPolicyVersionList
Set-Alias -Name Get-IAMRolePolicies -Value Get-IAMRolePolicyList
Set-Alias -Name Get-IAMRoles -Value Get-IAMRoleList
Set-Alias -Name Get-IAMSAMLProviders -Value Get-IAMSAMLProviderList
Set-Alias -Name Get-IAMServerCertificates -Value Get-IAMServerCertificateList
Set-Alias -Name Get-IAMUserPolicies -Value Get-IAMUserPolicyList
Set-Alias -Name Get-IAMUsers -Value Get-IAMUserList

# IoT
Set-Alias -Name Get-IOTAttachedPoliciesList -Value Get-IOTAttachedPolicyList
Set-Alias -Name Get-IOTAuthorizersList -Value Get-IOTAuthorizerList
Set-Alias -Name Get-IOTIndicesList -Value Get-IOTIndexList
Set-Alias -Name Get-IOTJobsList -Value Get-IOTJobList
Set-Alias -Name Get-IOTLoggingOptions -Value Get-IOTLoggingOption
Set-Alias -Name Get-IOTPolicyPrincipalsList -Value Get-IOTPolicyPrincipalList
Set-Alias -Name Get-IOTRoleAliasesList -Value Get-IOTRoleAliasList
Set-Alias -Name Get-IOTThingGroupsList -Value Get-IOTThingGroupList
Set-Alias -Name Get-IOTThingRegistrationTaskReportsList -Value Get-IOTThingRegistrationTaskReportList
Set-Alias -Name Get-IOTThingRegistrationTasksList -Value Get-IOTThingRegistrationTaskList
Set-Alias -Name Get-IOTThingTypesList -Value Get-IOTThingTypeList
Set-Alias -Name Get-IOTV2LoggingLevelsList -Value Get-IOTV2LoggingLevelList
Set-Alias -Name Get-IOTViolationEventsList -Value Get-IOTViolationEventList
Set-Alias -Name Set-IOTLoggingOptions -Value Set-IOTLoggingOption

# KeyManagementService
Set-Alias -Name Get-KMSAliases -Value Get-KMSAliasList
Set-Alias -Name Get-KMSGrants -Value Get-KMSGrantList
Set-Alias -Name Get-KMSKeyPolicies -Value Get-KMSKeyPolicyList
Set-Alias -Name Get-KMSKeys -Value Get-KMSKeyList

# Kinesis
Set-Alias -Name Get-KINStreams -Value Get-KINStreamList

# Lambda
Set-Alias -Name Get-LMEventSourceMappings -Value Get-LMEventSourceMappingList
Set-Alias -Name Get-LMFunctions -Value Get-LMFunctionList

# LexModelsV2
Set-Alias -Name Build-LMBV2BotLocale -Value Invoke-LMBV2BuildBotLocale

# MachineLearning
Set-Alias -Name Add-MLTag -Value Add-MLResourceTag
Set-Alias -Name Get-MLBatchPredictions -Value Get-MLBatchPredictionList
Set-Alias -Name Get-MLDataSources -Value Get-MLDataSourceList
Set-Alias -Name Get-MLEvaluations -Value Get-MLEvaluationList
Set-Alias -Name Get-MLModels -Value Get-MLModelList
Set-Alias -Name Get-MLTag -Value Get-MLResourceTag
Set-Alias -Name Remove-MLTag -Value Remove-MLResourceTag

# OpenSearchService
Set-Alias -Name Add-ESTag -Value Add-OSResourceTag
Set-Alias -Name Get-ESTag -Value Get-OSResourceTag
Set-Alias -Name Remove-ESTag -Value Remove-OSResourceTag

# OpsWorks
Set-Alias -Name Get-OPSApps -Value Get-OPSApp
Set-Alias -Name Get-OPSCommands -Value Get-OPSCommand
Set-Alias -Name Get-OPSDeployments -Value Get-OPSDeployment
Set-Alias -Name Get-OPSElasticIps -Value Get-OPSElasticIp
Set-Alias -Name Get-OPSElasticLoadBalancers -Value Get-OPSElasticLoadBalancer
Set-Alias -Name Get-OPSInstances -Value Get-OPSInstance
Set-Alias -Name Get-OPSLayers -Value Get-OPSLayer
Set-Alias -Name Get-OPSPermissions -Value Get-OPSPermission
Set-Alias -Name Get-OPSRaidArrays -Value Get-OPSRaidArray
Set-Alias -Name Get-OPSRdsDbInstances -Value Get-OPSRdsDbInstance
Set-Alias -Name Get-OPSServiceErrors -Value Get-OPSServiceError
Set-Alias -Name Get-OPSStackProvisioningParameters -Value Get-OPSStackProvisioningParameter
Set-Alias -Name Get-OPSStacks -Value Get-OPSStack
Set-Alias -Name Get-OPSUserProfiles -Value Get-OPSUserProfile
Set-Alias -Name Get-OPSVolumes -Value Get-OPSVolume

# Organizations
Set-Alias -Name Enable-ORGAllFeatures -Value Enable-ORGAllFeature

# RDS
Set-Alias -Name Get-RDSAccountAttributes -Value Get-RDSAccountAttribute
Set-Alias -Name Get-RDSCertificates -Value Get-RDSCertificate
Set-Alias -Name Get-RDSDBLogFiles -Value Get-RDSDBLogFile
Set-Alias -Name Get-RDSDBSnapshotAttributes -Value Get-RDSDBSnapshotAttribute
Set-Alias -Name Get-RDSEventCategories -Value Get-RDSEventCategory
Set-Alias -Name Get-RDSEventSubscriptions -Value Get-RDSEventSubscription
Set-Alias -Name Get-RDSPendingMaintenanceActions -Value Get-RDSPendingMaintenanceAction
Set-Alias -Name Get-RDSReservedDBInstancesOffering -Value New-RDSReservedDBInstancesOfferingPurchase
Set-Alias -Name Get-RDSReservedDBInstancesOfferings -Value Get-RDSReservedDBInstancesOfferingList

# RDSDataService
Set-Alias -Name Begin-RDSDTransaction -Value Start-RDSDTransaction
Set-Alias -Name Commit-RDSDTransaction -Value Confirm-RDSDTransaction
Set-Alias -Name Rollback-RDSDTransaction -Value Reset-RDSDTransaction

# Redshift
Set-Alias -Name Edit-RSClusterIamRoles -Value Edit-RSClusterIamRole
Set-Alias -Name Get-RSClusterParameterGroups -Value Get-RSClusterParameterGroup
Set-Alias -Name Get-RSClusterParameters -Value Get-RSClusterParameter
Set-Alias -Name Get-RSClusters -Value Get-RSCluster
Set-Alias -Name Get-RSClusterSecurityGroups -Value Get-RSClusterSecurityGroup
Set-Alias -Name Get-RSClusterSnapshots -Value Get-RSClusterSnapshot
Set-Alias -Name Get-RSClusterSubnetGroups -Value Get-RSClusterSubnetGroup
Set-Alias -Name Get-RSClusterVersions -Value Get-RSClusterVersion
Set-Alias -Name Get-RSDefaultClusterParameters -Value Get-RSDefaultClusterParameter
Set-Alias -Name Get-RSEventCategories -Value Get-RSEventCategory
Set-Alias -Name Get-RSEvents -Value Get-RSEvent
Set-Alias -Name Get-RSEventSubscriptions -Value Get-RSEventSubscription
Set-Alias -Name Get-RSHsmClientCertificates -Value Get-RSHsmClientCertificate
Set-Alias -Name Get-RSHsmConfigurations -Value Get-RSHsmConfiguration
Set-Alias -Name Get-RSOrderableClusterOptions -Value Get-RSOrderableClusterOption
Set-Alias -Name Get-RSReservedNodeOfferings -Value Get-RSReservedNodeOffering
Set-Alias -Name Get-RSReservedNodes -Value Get-RSReservedNode
Set-Alias -Name Get-RSTags -Value Get-RSResourceTag
Set-Alias -Name New-RSTags -Value New-RSResourceTag
Set-Alias -Name Remove-RSTags -Value Remove-RSResourceTag

# Rekognition
Set-Alias -Name Get-REKStreamProcessorsList -Value Get-REKStreamProcessorList

# Route53
Set-Alias -Name Get-R53CheckerIpRanges -Value Get-R53CheckerIpRange
Set-Alias -Name Get-R53GeoLocations -Value Get-R53GeoLocationList
Set-Alias -Name Get-R53HealthChecks -Value Get-R53HealthCheckList
Set-Alias -Name Get-R53HostedZones -Value Get-R53HostedZoneList
Set-Alias -Name Get-R53ReusableDelegationSets -Value Get-R53ReusableDelegationSetList
Set-Alias -Name Get-R53TagsForResources -Value Get-R53TagsForResourceList
Set-Alias -Name Get-R53TrafficPolicies -Value Get-R53TrafficPolicyList
Set-Alias -Name Get-R53TrafficPolicyInstances -Value Get-R53TrafficPolicyInstanceList
Set-Alias -Name Get-R53TrafficPolicyVersions -Value Get-R53TrafficPolicyVersionList

# Route53Domains
Set-Alias -Name Get-R53DDomainAvailability -Value Test-R53DDomainAvailability
Set-Alias -Name Get-R53DDomains -Value Get-R53DDomainList
Set-Alias -Name Get-R53DOperations -Value Get-R53DOperationList
Set-Alias -Name Update-R53DDomainNameservers -Value Update-R53DDomainNameserver

# S3
Set-Alias -Name Remove-S3MultipartUploads -Value Remove-S3MultipartUpload

# ServiceCatalog
Set-Alias -Name Get-SCAcceptedPortfolioSharesList -Value Get-SCAcceptedPortfolioShareList
Set-Alias -Name Get-SCProductPortfoliosList -Value Get-SCProductPortfolioList

# SimpleEmail
Set-Alias -Name Get-SESIdentityMailFromDomainAttributes -Value Get-SESIdentityMailFromDomainAttribute
Set-Alias -Name Get-SESReceiptFilters -Value Get-SESReceiptFilterList
Set-Alias -Name Get-SESReceiptRuleSets -Value Get-SESReceiptRuleSetList
Set-Alias -Name Get-SESSendStatistics -Value Get-SESSendStatistic

# SimpleNotificationService
Set-Alias -Name Get-SNSEndpointAttributes -Value Get-SNSEndpointAttribute
Set-Alias -Name Get-SNSPlatformApplicationAttributes -Value Get-SNSPlatformApplicationAttribute
Set-Alias -Name Get-SNSPlatformApplications -Value Get-SNSPlatformApplicationList
Set-Alias -Name Get-SNSSMSAttributes -Value Get-SNSSMSAttribute
Set-Alias -Name Set-SNSEndpointAttributes -Value Set-SNSEndpointAttribute
Set-Alias -Name Set-SNSPlatformApplicationAttributes -Value Set-SNSPlatformApplicationAttribute
Set-Alias -Name Set-SNSSMSAttributes -Value Set-SNSSMSAttribute

# SimpleSystemsManagement
Set-Alias -Name Get-SSMComplianceItemsList -Value Get-SSMComplianceItemList
Set-Alias -Name Get-SSMComplianceSummariesList -Value Get-SSMComplianceSummaryList
Set-Alias -Name Get-SSMInventoryEntriesList -Value Get-SSMInventoryEntryList
Set-Alias -Name Get-SSMMaintenanceWindowTargets -Value Get-SSMMaintenanceWindowTarget
Set-Alias -Name Get-SSMParameterNameList -Value Get-SSMParameterValue
Set-Alias -Name Get-SSMResourceComplianceSummariesList -Value Get-SSMResourceComplianceSummaryList

# Snowball
Set-Alias -Name Get-SNOWJobsList -Value Get-SNOWJobList

# SQS
Set-Alias -Name Get-SQSDeadLetterSourceQueues -Value Get-SQSDeadLetterSourceQueue

# StorageGateway
Set-Alias -Name Get-SGChapCredentials -Value Get-SGChapCredential
Set-Alias -Name Get-SGResourceTags -Value Get-SGResourceTag
Set-Alias -Name Get-SGTapeArchives -Value Get-SGTapeArchiveList
Set-Alias -Name Get-SGTapeRecoveryPoints -Value Get-SGTapeRecoveryPointList
Set-Alias -Name Get-SGTapes -Value Get-SGTapeList
Set-Alias -Name Get-SGVolumeInitiators -Value Get-SGVolumeInitiatorList
Set-Alias -Name Get-SGVTLDevices -Value Get-SGVTLDevice
Set-Alias -Name New-SGTapes -Value New-SGTape
Set-Alias -Name Remove-SGChapCredentials -Value Remove-SGChapCredential
Set-Alias -Name Update-SGChapCredentials -Value Update-SGChapCredential

# WellArchitected
Set-Alias -Name Add-WATLense -Value Register-WATLens
Set-Alias -Name Get-WATLenseList -Value Get-WATLensList
Set-Alias -Name Remove-WATLense -Value Unregister-WATLens

# WorkSpaces
Set-Alias -Name Get-WKSWorkspaceBundles -Value Get-WKSWorkspaceBundle
Set-Alias -Name Get-WKSWorkspaceDirectories -Value Get-WKSWorkspaceDirectory
Set-Alias -Name Get-WKSWorkspaces -Value Get-WKSWorkspace

Export-ModuleMember -Alias *
# SIG # Begin signature block
# MIIfKgYJKoZIhvcNAQcCoIIfGzCCHxcCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAc1mQ5/y5U8NI2
# ddNsOu/+ZrPPDzrvVfnQOgi34DA2tKCCDlkwggawMIIEmKADAgECAhAIrUCyYNKc
# TJ9ezam9k67ZMA0GCSqGSIb3DQEBDAUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQK
# EwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNV
# BAMTGERpZ2lDZXJ0IFRydXN0ZWQgUm9vdCBHNDAeFw0yMTA0MjkwMDAwMDBaFw0z
# NjA0MjgyMzU5NTlaMGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwg
# SW5jLjFBMD8GA1UEAxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcg
# UlNBNDA5NiBTSEEzODQgMjAyMSBDQTEwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAw
# ggIKAoICAQDVtC9C0CiteLdd1TlZG7GIQvUzjOs9gZdwxbvEhSYwn6SOaNhc9es0
# JAfhS0/TeEP0F9ce2vnS1WcaUk8OoVf8iJnBkcyBAz5NcCRks43iCH00fUyAVxJr
# Q5qZ8sU7H/Lvy0daE6ZMswEgJfMQ04uy+wjwiuCdCcBlp/qYgEk1hz1RGeiQIXhF
# LqGfLOEYwhrMxe6TSXBCMo/7xuoc82VokaJNTIIRSFJo3hC9FFdd6BgTZcV/sk+F
# LEikVoQ11vkunKoAFdE3/hoGlMJ8yOobMubKwvSnowMOdKWvObarYBLj6Na59zHh
# 3K3kGKDYwSNHR7OhD26jq22YBoMbt2pnLdK9RBqSEIGPsDsJ18ebMlrC/2pgVItJ
# wZPt4bRc4G/rJvmM1bL5OBDm6s6R9b7T+2+TYTRcvJNFKIM2KmYoX7BzzosmJQay
# g9Rc9hUZTO1i4F4z8ujo7AqnsAMrkbI2eb73rQgedaZlzLvjSFDzd5Ea/ttQokbI
# YViY9XwCFjyDKK05huzUtw1T0PhH5nUwjewwk3YUpltLXXRhTT8SkXbev1jLchAp
# QfDVxW0mdmgRQRNYmtwmKwH0iU1Z23jPgUo+QEdfyYFQc4UQIyFZYIpkVMHMIRro
# OBl8ZhzNeDhFMJlP/2NPTLuqDQhTQXxYPUez+rbsjDIJAsxsPAxWEQIDAQABo4IB
# WTCCAVUwEgYDVR0TAQH/BAgwBgEB/wIBADAdBgNVHQ4EFgQUaDfg67Y7+F8Rhvv+
# YXsIiGX0TkIwHwYDVR0jBBgwFoAU7NfjgtJxXWRM3y5nP+e6mK4cD08wDgYDVR0P
# AQH/BAQDAgGGMBMGA1UdJQQMMAoGCCsGAQUFBwMDMHcGCCsGAQUFBwEBBGswaTAk
# BggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEEGCCsGAQUFBzAC
# hjVodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkUm9v
# dEc0LmNydDBDBgNVHR8EPDA6MDigNqA0hjJodHRwOi8vY3JsMy5kaWdpY2VydC5j
# b20vRGlnaUNlcnRUcnVzdGVkUm9vdEc0LmNybDAcBgNVHSAEFTATMAcGBWeBDAED
# MAgGBmeBDAEEATANBgkqhkiG9w0BAQwFAAOCAgEAOiNEPY0Idu6PvDqZ01bgAhql
# +Eg08yy25nRm95RysQDKr2wwJxMSnpBEn0v9nqN8JtU3vDpdSG2V1T9J9Ce7FoFF
# UP2cvbaF4HZ+N3HLIvdaqpDP9ZNq4+sg0dVQeYiaiorBtr2hSBh+3NiAGhEZGM1h
# mYFW9snjdufE5BtfQ/g+lP92OT2e1JnPSt0o618moZVYSNUa/tcnP/2Q0XaG3Ryw
# YFzzDaju4ImhvTnhOE7abrs2nfvlIVNaw8rpavGiPttDuDPITzgUkpn13c5Ubdld
# AhQfQDN8A+KVssIhdXNSy0bYxDQcoqVLjc1vdjcshT8azibpGL6QB7BDf5WIIIJw
# 8MzK7/0pNVwfiThV9zeKiwmhywvpMRr/LhlcOXHhvpynCgbWJme3kuZOX956rEnP
# LqR0kq3bPKSchh/jwVYbKyP/j7XqiHtwa+aguv06P0WmxOgWkVKLQcBIhEuWTatE
# QOON8BUozu3xGFYHKi8QxAwIZDwzj64ojDzLj4gLDb879M4ee47vtevLt/B3E+bn
# KD+sEq6lLyJsQfmCXBVmzGwOysWGw/YmMwwHS6DTBwJqakAwSEs0qFEgu60bhQji
# WQ1tygVQK+pKHJ6l/aCnHwZ05/LWUpD9r4VIIflXO7ScA+2GRfS0YW6/aOImYIbq
# yK+p/pQd52MbOoZWeE4wggehMIIFiaADAgECAhALyko14sGCglkXWPsT8gmbMA0G
# CSqGSIb3DQEBCwUAMGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwg
# SW5jLjFBMD8GA1UEAxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcg
# UlNBNDA5NiBTSEEzODQgMjAyMSBDQTEwHhcNMjExMjI4MDAwMDAwWhcNMjMwMTAz
# MjM1OTU5WjCB9jEdMBsGA1UEDwwUUHJpdmF0ZSBPcmdhbml6YXRpb24xEzARBgsr
# BgEEAYI3PAIBAxMCVVMxGTAXBgsrBgEEAYI3PAIBAhMIRGVsYXdhcmUxEDAOBgNV
# BAUTBzQxNTI5NTQxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAw
# DgYDVQQHEwdTZWF0dGxlMSIwIAYDVQQKExlBbWF6b24gV2ViIFNlcnZpY2VzLCBJ
# bmMuMRcwFQYDVQQLEw5TREtzIGFuZCBUb29sczEiMCAGA1UEAxMZQW1hem9uIFdl
# YiBTZXJ2aWNlcywgSW5jLjCCAaIwDQYJKoZIhvcNAQEBBQADggGPADCCAYoCggGB
# AKHRLdQSyJ6AfhQ8U7Gi6le7gshUhu34xQ7jaTCfpKaKQRGu+oNfAYDRSSfh498e
# K+jFnGHU/TMzVHEgBb4TUrc1e2f5LHhXAtYTJK0uis9OJ5n3MjHwOJt/uGSSMUAI
# IIselvbSF2mOE0lIz0CNMIlUiXI9O+y9+FJP7Vsg/NU/zAVsQ4Ok0GLd+Yp566nR
# uj9aNU+L+TxRhSHA7KKjJ9oE0mVblUGQaeNrOd1Ql9djJy0pg6oT2s9Peh8lqB3t
# UsMaoQ/FMV0P/e1S6V3yFg/I1OvQdtm29ryJTdg9ZvIV/FGnIYdW5s5T8t//nf+7
# LToQVhpML/ZWEhFRAa6We80Y8zs9glIPDZyYmi6OPbpY7kVHa4dr8S49tPwrVMjC
# 3hk9v9S6poDx/hR9kytwVt1Lo4LjAlpmKLeHVmOnn5uenpXqFOJMbTMYmciwHz8y
# WJwZYMKKLJPCGa79xaAkZj9HCop5yPUPccqjyz2i0v/Pt8yFH77s8q86e99O2a+/
# oQIDAQABo4ICNTCCAjEwHwYDVR0jBBgwFoAUaDfg67Y7+F8Rhvv+YXsIiGX0TkIw
# HQYDVR0OBBYEFGmlIp+0bnVEmnOvWcJjnCup9DbsMC4GA1UdEQQnMCWgIwYIKwYB
# BQUHCAOgFzAVDBNVUy1ERUxBV0FSRS00MTUyOTU0MA4GA1UdDwEB/wQEAwIHgDAT
# BgNVHSUEDDAKBggrBgEFBQcDAzCBtQYDVR0fBIGtMIGqMFOgUaBPhk1odHRwOi8v
# Y3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkRzRDb2RlU2lnbmluZ1JT
# QTQwOTZTSEEzODQyMDIxQ0ExLmNybDBToFGgT4ZNaHR0cDovL2NybDQuZGlnaWNl
# cnQuY29tL0RpZ2lDZXJ0VHJ1c3RlZEc0Q29kZVNpZ25pbmdSU0E0MDk2U0hBMzg0
# MjAyMUNBMS5jcmwwPQYDVR0gBDYwNDAyBgVngQwBAzApMCcGCCsGAQUFBwIBFhto
# dHRwOi8vd3d3LmRpZ2ljZXJ0LmNvbS9DUFMwgZQGCCsGAQUFBwEBBIGHMIGEMCQG
# CCsGAQUFBzABhhhodHRwOi8vb2NzcC5kaWdpY2VydC5jb20wXAYIKwYBBQUHMAKG
# UGh0dHA6Ly9jYWNlcnRzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydFRydXN0ZWRHNENv
# ZGVTaWduaW5nUlNBNDA5NlNIQTM4NDIwMjFDQTEuY3J0MAwGA1UdEwEB/wQCMAAw
# DQYJKoZIhvcNAQELBQADggIBALlYa6PSDPPulVJbqEi7XGz23lFZwYa1PiXk+PkJ
# O2HDXv2zep26LZriwBHT2yA/KbDvbwZpf4VOBKn5lQC9R+DsgwW/xZbNq7y3cWf9
# Ad1AQ9Do/FXfBqVO1if+GpqFbqUme5wOjn8/8dc4nFR4erbDgkM4ICn/astBigYn
# fM5wTO+J8ex+7fE2D1kFAwfZAuiRNdDreVMDlYXpJMQ4CtTKVLHYentLR747zzRj
# O4PqgL1exvbvpOMZlSDLWhaDjtKwUDb645ziHDA3DXe8K51+hIFuadKTinJa8Pfs
# bgg2W7aTfBdi2gTyXkeVJ836631Ks4KD3cXui9Jx2PWRAVxKIEvXuebZ09Mph2ji
# BH75urqS57i1mpS7OA5lIj7a7NIYsVl26PVpJUEr3LRKV8GO3tRC7KP0zE7sB7k2
# VQKwBXbsifq/vpcmeyy4OeQbZ1i8GwZLPHuygP9exTWK2o2wWByJs62Wdk6JmSRE
# vr9Wr59BVNbQfRSRaF9q058bBK68hGZtDBpJ9gJX4V12DI2UpSbcGf10+afL1J4z
# FDv98GIGkgmfLQJUpJeC/FnNrEXJbINndCsOb6gdLvLX1grMdUPmPkpRZyvG3HEy
# EMCV5ODMItTx7K6TDyeZDIXXP5oBnBMK9EjtRD3XkEb9dDfuzCrdlTpEoTElt2mG
# uEE7MYIQJzCCECMCAQEwfTBpMQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNl
# cnQsIEluYy4xQTA/BgNVBAMTOERpZ2lDZXJ0IFRydXN0ZWQgRzQgQ29kZSBTaWdu
# aW5nIFJTQTQwOTYgU0hBMzg0IDIwMjEgQ0ExAhALyko14sGCglkXWPsT8gmbMA0G
# CWCGSAFlAwQCAQUAoHwwEAYKKwYBBAGCNwIBDDECMAAwGQYJKoZIhvcNAQkDMQwG
# CisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZI
# hvcNAQkEMSIEIHtVLIsKVbnNPBLMDNER0ITjjD3dVJB4lxPqdMdG5TMBMA0GCSqG
# SIb3DQEBAQUABIIBgIQdXEkpbU3JeWetH+g5m0V+gWLEr7TOtncvFYhTmVtqQvwu
# CVx1DiEEq2+lFdCN0IHY9pqXWxKDG6Yf28IDpZtY/gtMuNGkRJKPTSLYZ+GANJqB
# mcrfxo4UDugFWapHrhRb6y+qjNm2gDxBD+duxjv7OGJOPXuRayQVxay2de4SBEfI
# /naafl7ZpwUXspxBIktjlcPSYmkuuQJHDGkKkuWqVDpp9Kz7XV0jZ5+Q6D5asJFi
# L0XToN5mUutTHaWkyqeRbWlsi5UHvmG3Ff0uDEwkgnuGAmCf2TGNXh97N1rRmWkw
# t6m8j1AZ7iMQS4wva0/eaakv0HfrIpb5qIdsiPbnWhznmHPRoumDucRMhe7y8+UH
# jKF71CiwNod5keo7SVL3IBsc52eafTtof3gpMBAA4RCw7CnIuEyX3Zh81kT+xp14
# QhmJQH3i0lvi+nDfTl55NLXMsH/G34LoBNNBGB7Ve5dktYwgGvZascu4oUp9x9Z/
# EyRCeG6U2chItJEFraGCDX0wgg15BgorBgEEAYI3AwMBMYINaTCCDWUGCSqGSIb3
# DQEHAqCCDVYwgg1SAgEDMQ8wDQYJYIZIAWUDBAIBBQAwdwYLKoZIhvcNAQkQAQSg
# aARmMGQCAQEGCWCGSAGG/WwHATAxMA0GCWCGSAFlAwQCAQUABCBU61NoRCz1ruDL
# SVCyWMIJwEYCefg28NSkj6wArsvdTgIQKKa4QJXw0FS1otjNTRwvHBgPMjAyMjAz
# MDcyMjQxNTFaoIIKNzCCBP4wggPmoAMCAQICEA1CSuC+Ooj/YEAhzhQA8N0wDQYJ
# KoZIhvcNAQELBQAwcjELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0IElu
# YzEZMBcGA1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTExMC8GA1UEAxMoRGlnaUNlcnQg
# U0hBMiBBc3N1cmVkIElEIFRpbWVzdGFtcGluZyBDQTAeFw0yMTAxMDEwMDAwMDBa
# Fw0zMTAxMDYwMDAwMDBaMEgxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2Vy
# dCwgSW5jLjEgMB4GA1UEAxMXRGlnaUNlcnQgVGltZXN0YW1wIDIwMjEwggEiMA0G
# CSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDC5mGEZ8WK9Q0IpEXKY2tR1zoRQr0K
# dXVNlLQMULUmEP4dyG+RawyW5xpcSO9E5b+bYc0VkWJauP9nC5xj/TZqgfop+N0r
# cIXeAhjzeG28ffnHbQk9vmp2h+mKvfiEXR52yeTGdnY6U9HR01o2j8aj4S8bOrdh
# 1nPsTm0zinxdRS1LsVDmQTo3VobckyON91Al6GTm3dOPL1e1hyDrDo4s1SPa9E14
# RuMDgzEpSlwMMYpKjIjF9zBa+RSvFV9sQ0kJ/SYjU/aNY+gaq1uxHTDCm2mCtNv8
# VlS8H6GHq756WwogL0sJyZWnjbL61mOLTqVyHO6fegFz+BnW/g1JhL0BAgMBAAGj
# ggG4MIIBtDAOBgNVHQ8BAf8EBAMCB4AwDAYDVR0TAQH/BAIwADAWBgNVHSUBAf8E
# DDAKBggrBgEFBQcDCDBBBgNVHSAEOjA4MDYGCWCGSAGG/WwHATApMCcGCCsGAQUF
# BwIBFhtodHRwOi8vd3d3LmRpZ2ljZXJ0LmNvbS9DUFMwHwYDVR0jBBgwFoAU9Lbh
# IB3+Ka7S5GGlsqIlssgXNW4wHQYDVR0OBBYEFDZEho6kurBmvrwoLR1ENt3janq8
# MHEGA1UdHwRqMGgwMqAwoC6GLGh0dHA6Ly9jcmwzLmRpZ2ljZXJ0LmNvbS9zaGEy
# LWFzc3VyZWQtdHMuY3JsMDKgMKAuhixodHRwOi8vY3JsNC5kaWdpY2VydC5jb20v
# c2hhMi1hc3N1cmVkLXRzLmNybDCBhQYIKwYBBQUHAQEEeTB3MCQGCCsGAQUFBzAB
# hhhodHRwOi8vb2NzcC5kaWdpY2VydC5jb20wTwYIKwYBBQUHMAKGQ2h0dHA6Ly9j
# YWNlcnRzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydFNIQTJBc3N1cmVkSURUaW1lc3Rh
# bXBpbmdDQS5jcnQwDQYJKoZIhvcNAQELBQADggEBAEgc3LXpmiO85xrnIA6OZ0b9
# QnJRdAojR6OrktIlxHBZvhSg5SeBpU0UFRkHefDRBMOG2Tu9/kQCZk3taaQP9rhw
# z2Lo9VFKeHk2eie38+dSn5On7UOee+e03UEiifuHokYDTvz0/rdkd2NfI1Jpg4L6
# GlPtkMyNoRdzDfTzZTlwS/Oc1np72gy8PTLQG8v1Yfx1CAB2vIEO+MDhXM/EEXLn
# G2RJ2CKadRVC9S0yOIHa9GCiurRS+1zgYSQlT7LfySmoc0NR2r1j1h9bm/cuG08T
# HfdKDXF+l7f0P4TrweOjSaH6zqe/Vs+6WXZhiV9+p7SOZ3j5NpjhyyjaW4emii8w
# ggUxMIIEGaADAgECAhAKoSXW1jIbfkHkBdo2l8IVMA0GCSqGSIb3DQEBCwUAMGUx
# CzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3
# dy5kaWdpY2VydC5jb20xJDAiBgNVBAMTG0RpZ2lDZXJ0IEFzc3VyZWQgSUQgUm9v
# dCBDQTAeFw0xNjAxMDcxMjAwMDBaFw0zMTAxMDcxMjAwMDBaMHIxCzAJBgNVBAYT
# AlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2Vy
# dC5jb20xMTAvBgNVBAMTKERpZ2lDZXJ0IFNIQTIgQXNzdXJlZCBJRCBUaW1lc3Rh
# bXBpbmcgQ0EwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQC90DLuS82P
# f92puoKZxTlUKFe2I0rEDgdFM1EQfdD5fU1ofue2oPSNs4jkl79jIZCYvxO8V9PD
# 4X4I1moUADj3Lh477sym9jJZ/l9lP+Cb6+NGRwYaVX4LJ37AovWg4N4iPw7/fpX7
# 86O6Ij4YrBHk8JkDbTuFfAnT7l3ImgtU46gJcWvgzyIQD3XPcXJOCq3fQDpct1Hh
# oXkUxk0kIzBdvOw8YGqsLwfM/fDqR9mIUF79Zm5WYScpiYRR5oLnRlD9lCosp+R1
# PrqYD4R/nzEU1q3V8mTLex4F0IQZchfxFwbvPc3WTe8GQv2iUypPhR3EHTyvz9qs
# EPXdrKzpVv+TAgMBAAGjggHOMIIByjAdBgNVHQ4EFgQU9LbhIB3+Ka7S5GGlsqIl
# ssgXNW4wHwYDVR0jBBgwFoAUReuir/SSy4IxLVGLp6chnfNtyA8wEgYDVR0TAQH/
# BAgwBgEB/wIBADAOBgNVHQ8BAf8EBAMCAYYwEwYDVR0lBAwwCgYIKwYBBQUHAwgw
# eQYIKwYBBQUHAQEEbTBrMCQGCCsGAQUFBzABhhhodHRwOi8vb2NzcC5kaWdpY2Vy
# dC5jb20wQwYIKwYBBQUHMAKGN2h0dHA6Ly9jYWNlcnRzLmRpZ2ljZXJ0LmNvbS9E
# aWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5jcnQwgYEGA1UdHwR6MHgwOqA4oDaGNGh0
# dHA6Ly9jcmw0LmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5j
# cmwwOqA4oDaGNGh0dHA6Ly9jcmwzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3Vy
# ZWRJRFJvb3RDQS5jcmwwUAYDVR0gBEkwRzA4BgpghkgBhv1sAAIEMCowKAYIKwYB
# BQUHAgEWHGh0dHBzOi8vd3d3LmRpZ2ljZXJ0LmNvbS9DUFMwCwYJYIZIAYb9bAcB
# MA0GCSqGSIb3DQEBCwUAA4IBAQBxlRLpUYdWac3v3dp8qmN6s3jPBjdAhO9LhL/K
# zwMC/cWnww4gQiyvd/MrHwwhWiq3BTQdaq6Z+CeiZr8JqmDfdqQ6kw/4stHYfBli
# 6F6CJR7Euhx7LCHi1lssFDVDBGiy23UC4HLHmNY8ZOUfSBAYX4k4YU1iRiSHY4yR
# UiyvKYnleB/WCxSlgNcSR3CzddWThZN+tpJn+1Nhiaj1a5bA9FhpDXzIAbG5KHW3
# mWOFIoxhynmUfln8jA/jb7UBJrZspe6HUSHkWGCbugwtK22ixH67xCUrRwIIfEmu
# E7bhfEJCKMYYVs9BNLZmXbZ0e/VWMyIvIjayS6JKldj1po5SMYIChjCCAoICAQEw
# gYYwcjELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0IEluYzEZMBcGA1UE
# CxMQd3d3LmRpZ2ljZXJ0LmNvbTExMC8GA1UEAxMoRGlnaUNlcnQgU0hBMiBBc3N1
# cmVkIElEIFRpbWVzdGFtcGluZyBDQQIQDUJK4L46iP9gQCHOFADw3TANBglghkgB
# ZQMEAgEFAKCB0TAaBgkqhkiG9w0BCQMxDQYLKoZIhvcNAQkQAQQwHAYJKoZIhvcN
# AQkFMQ8XDTIyMDMwNzIyNDE1MVowKwYLKoZIhvcNAQkQAgwxHDAaMBgwFgQU4deC
# qOGRvu9ryhaRtaq0lKYkm/MwLwYJKoZIhvcNAQkEMSIEIG/SclQCsOkoUVIvqaNS
# 3LFdomggf0CqrTSN7QhchP5rMDcGCyqGSIb3DQEJEAIvMSgwJjAkMCIEILMQkAa8
# CtmDB5FXKeBEA0Fcg+MpK2FPJpZMjTVx7PWpMA0GCSqGSIb3DQEBAQUABIIBABu/
# iZfrn5QB5F20MxXOO0QNFyXBcHOTlJebUAf/v5A7cMIhm3e6UWAZ83gW8C+Uw42W
# V92Ur8mw5wiWkxi4FExIacJOMfH0fZJdLwOQDNGKrZi0Hz8iBtsLYA3J5t7QRAuk
# Y01f4p6dUpgAHb+3wy69ZIm3FMXnRU0a/PyQlbU2ys0Od8O4vFMjBwGLeaZLjL2D
# klUklCJmRTdi9rgiCTD1JUrqR8i0VIftZg4FSoURjoGfZsJbGHXgLfAsnS9uNKpR
# 9kqyYcUqUjO3mYOD/XeU7QS8vON3daZBZfvnpCvse8z+RB8E5+Cws37ohbS+/Xyy
# e3tRl1X4nhcXbl3HaVs=
# SIG # End signature block
